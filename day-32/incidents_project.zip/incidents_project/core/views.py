# core/views.py

from django.shortcuts import render, redirect
from django.contrib.auth import login
from django.contrib.auth.decorators import login_required
from .forms import RegisterForm, IncidentForm
from .models import Incident, Customer
from django.contrib.auth.models import User
from django.db.models import Count
from django.http import JsonResponse
import json

def register(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            phone = form.cleaned_data.get('phone')
            Customer.objects.create(user=user, phone=phone or '')
            login(request, user)
            return redirect('dashboard')
    else:
        form = RegisterForm()
    return render(request, 'registration/register.html', {'form': form})

def about(request):
    return render(request, 'about.html')

def customers(request):
    # Simple customers list
    customers = Customer.objects.select_related('user').all()
    return render(request, 'customers.html', {'customers': customers})

@login_required
def incidents(request):
    # Show list and allow registered users to create an incident.
    if request.method == 'POST':
        form = IncidentForm(request.POST)
        if form.is_valid():
            incident = form.save(commit=False)
            incident.created_by = request.user
            incident.save()
            return redirect('incidents')
    else:
        form = IncidentForm()

    incidents_list = Incident.objects.select_related('created_by').order_by('-created_at')
    return render(request, 'incidents.html', {'form': form, 'incidents': incidents_list})

def dashboard(request):
    # Prepare counts by category and by city for charting.
    # If database is empty, you might want to run the sample data loader manually (see README),
    # but we'll still compute counts safely.
    cat_qs = Incident.objects.values('category').annotate(count=Count('id'))
    city_qs = Incident.objects.values('city').annotate(count=Count('id'))

    # Build dicts with consistent ordering for chart labels
    categories = ['EMS', 'TRAFFIC', 'FIRE', 'OTHER']
    cities = ['Trivandrum', 'Bangalore', 'Hyderabad', 'Chennai']

    cat_counts = {c: 0 for c in categories}
    for row in cat_qs:
        cat_counts[row['category']] = row['count']

    city_counts = {c: 0 for c in cities}
    for row in city_qs:
        city_counts[row['city']] = row['count']

    context = {
        'cat_labels': list(cat_counts.keys()),
        'cat_values': list(cat_counts.values()),
        'city_labels': list(city_counts.keys()),
        'city_values': list(city_counts.values()),
    }
    return render(request, 'dashboard.html', context)


## Added to handle logout
## LOGOUT_REDIRECT_URL = 'dashboard' -> Can be an alternative

# from django.contrib.auth.views import LogoutView

# class CustomLogoutView(LogoutView):
#     next_page = 'dashboard'

#     def get(self, request, *args, **kwargs):
#         return self.post(request, *args, **kwargs)
