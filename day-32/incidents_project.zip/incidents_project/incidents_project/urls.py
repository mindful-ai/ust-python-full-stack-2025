# incidents_demo/urls.py

from django.contrib import admin
from django.urls import path, include
from core import views as core_views
from django.contrib.auth import views as auth_views
from django.contrib.auth.views import LogoutView

urlpatterns = [
    path('admin/', admin.site.urls),

    # core pages
    path('', core_views.dashboard, name='dashboard'),
    path('incidents/', core_views.incidents, name='incidents'),
    path('customers/', core_views.customers, name='customers'),
    path('about/', core_views.about, name='about'),

    # registration
    path('register/', core_views.register, name='register'),

    # auth: login/logout using Django's views but custom templates
    path('login/', auth_views.LoginView.as_view(template_name='registration/login.html'), name='login'),
    path('logout/', LogoutView.as_view(), name='logout'),
]

